#!/usr/bin/env python3
"""
make_test_plate.py — a synthetic stand-in for a bought plate.

Projects a real 3D screen rectangle through a moving pinhole camera,
puts a generic desktop on it, and dirties the result with glare,
vignette, lens blur and grain. It exists to prove the tracker and the
grade before real footage lands, and to be a regression test after —
the ground-truth corners are written alongside it.
"""

import json
import os

import cv2
import numpy as np

W, H, FPS, N = 1920, 1080, 30, 180
OUT = os.path.join(os.path.dirname(__file__), '..', 'work', 'test-plate')
os.makedirs(OUT, exist_ok=True)

# screen plane in metres, 16:10, tilted back a little
SW, SH = 0.344, 0.215
TILT = np.deg2rad(11.0)


def rot_x(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def rot_y(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def corners_3d(scale=1.0):
    x, y = SW / 2 * scale, SH / 2 * scale
    pts = np.array([[-x, y, 0], [x, y, 0], [x, -y, 0], [-x, -y, 0]], np.float64)
    return pts @ rot_x(TILT).T


def ease(t):
    return t * t * (3 - 2 * t)


def look_at(eye, target):
    """World-to-camera rotation for a camera at `eye` aimed at `target`,
    looking down its own -z."""
    fwd = target - eye
    fwd /= np.linalg.norm(fwd)
    right = np.cross(fwd, np.array([0.0, 1.0, 0.0]))
    right /= np.linalg.norm(right)
    up = np.cross(right, fwd)
    return np.stack([right, up, -fwd])


def camera(t):
    """Slow push with a touch of orbit, plus handheld drift. The camera
    is aimed at the screen rather than given fixed angles, so the quad
    stays in frame however the move is retimed."""
    e = ease(t)
    eye = np.array([
        0.190 - 0.110 * e + 0.005 * np.sin(t * 7.1),
        0.130 - 0.052 * e + 0.004 * np.sin(t * 5.3 + 1.1),
        0.620 - 0.165 * e,
    ])
    # the aim wanders a little, which is what makes handheld read as handheld
    target = np.array([
        0.004 * np.sin(t * 4.3 + 0.6),
        0.003 * np.sin(t * 3.7),
        0.0,
    ])
    R = look_at(eye, target)
    f = 1320 + 240 * e
    return eye, R, f


def project(pts, eye, R, f):
    cam = (pts - eye) @ R.T
    z = np.clip(-cam[:, 2], 1e-4, None)
    x = f * cam[:, 0] / z + W / 2
    y = -f * cam[:, 1] / z + H / 2
    return np.stack([x, y], 1).astype(np.float32)


def desktop_image(w=1440, h=900):
    """Something with enough edges and text to give the tracker purchase."""
    img = np.full((h, w, 3), 236, np.uint8)
    cv2.rectangle(img, (0, 0), (w, 34), (248, 248, 248), -1)
    for i, x in enumerate(range(28, 360, 68)):
        cv2.putText(img, 'Menu'[:4], (x, 23), cv2.FONT_HERSHEY_SIMPLEX,
                    0.52, (90, 90, 90), 1, cv2.LINE_AA)
    cv2.rectangle(img, (120, 110), (w - 150, h - 130), (255, 255, 255), -1)
    cv2.rectangle(img, (120, 110), (w - 150, h - 130), (205, 205, 205), 2)
    cv2.rectangle(img, (120, 110), (w - 150, 156), (240, 240, 240), -1)
    for i, c in enumerate([(90, 95, 240), (80, 190, 240), (110, 200, 120)]):
        cv2.circle(img, (146 + i * 22, 133), 7, c, -1)
    rng = np.random.default_rng(7)
    y = 200
    while y < h - 170:
        ln = int(rng.integers(220, w - 420))
        cv2.rectangle(img, (160, y), (160 + ln, y + 11), (198, 198, 198), -1)
        y += 30
    cv2.rectangle(img, (w - 430, 200), (w - 180, 430), (228, 234, 246), -1)
    cv2.putText(img, 'Inspector', (w - 418, 232), cv2.FONT_HERSHEY_SIMPLEX,
                0.58, (110, 120, 150), 1, cv2.LINE_AA)
    return img


def desk_texture(n=1400):
    """Wood grain with enough detail to be trackable."""
    rng = np.random.default_rng(3)
    base = np.zeros((n, n, 3), np.float32)
    base[..., 0], base[..., 1], base[..., 2] = 0.22, 0.33, 0.47
    grain = rng.normal(0, 1, (n, n))
    grain = cv2.GaussianBlur(grain, (0, 0), 1.2)
    grain += cv2.GaussianBlur(rng.normal(0, 1, (n, n)), (0, 0), 14) * 2.2
    # stretch along one axis so it reads as grain rather than noise
    grain = cv2.resize(grain, (n, n // 7))
    grain = cv2.resize(grain, (n, n), interpolation=cv2.INTER_LINEAR)
    base += (grain * 0.028)[..., None]
    for _ in range(26):                      # knots and marks to lock onto
        c = (int(rng.integers(0, n)), int(rng.integers(0, n)))
        cv2.ellipse(base, c, (int(rng.integers(8, 46)), int(rng.integers(4, 18))),
                    float(rng.integers(0, 180)), 0, 360,
                    (0.16, 0.25, 0.37), -1, cv2.LINE_AA)
    return np.clip(cv2.GaussianBlur(base, (0, 0), 0.8), 0, 1)


DESK_TEX = None


def background(eye, R, f):
    """The desk, projected through the same camera as the screen.

    This has to move with the camera. A background painted once and
    reused every frame is static in screen space, so every feature on
    it reports zero motion and drags the homography toward identity —
    which is a property of the fake, not of any real plate.
    """
    global DESK_TEX
    if DESK_TEX is None:
        DESK_TEX = desk_texture()
    th, tw = DESK_TEX.shape[:2]

    # a big horizontal plane under the screen, in metres
    y0 = -SH / 2 * np.cos(TILT) - 0.015
    plane = np.array([[-0.9, y0, -0.7], [0.9, y0, -0.7],
                      [0.9, y0, 0.9], [-0.9, y0, 0.9]], np.float64)
    quad = project(plane, eye, R, f)

    img = np.zeros((H, W, 3), np.float32)
    img[:] = (0.16, 0.22, 0.31)                     # the dark beyond the desk
    M = cv2.getPerspectiveTransform(
        np.array([[0, 0], [tw, 0], [tw, th], [0, th]], np.float32), quad)
    warped = cv2.warpPerspective(DESK_TEX, M, (W, H), flags=cv2.INTER_LINEAR)
    m = np.zeros((H, W), np.float32)
    cv2.fillConvexPoly(m, quad.astype(np.int32), 1.0)
    m = cv2.GaussianBlur(m, (5, 5), 0)[..., None]
    img = img * (1 - m) + warped * m

    # a practical light pooling on the desk
    gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
    d = np.sqrt((gx / W - 0.2) ** 2 + (gy / H - 0.1) ** 2)
    img += (0.20 * np.clip(1 - d / 0.45, 0, 1) ** 2)[..., None]

    # the desk sits out of focus relative to the screen
    return cv2.GaussianBlur(np.clip(img, 0, 1), (0, 0), 3.4)


def main():
    content = desktop_image().astype(np.float32) / 255.0
    ch, cw = content.shape[:2]
    src = np.array([[0, 0], [cw, 0], [cw, ch], [0, ch]], np.float32)

    truth = {}
    rng = np.random.default_rng(11)

    for i in range(N):
        t = i / (N - 1)
        eye, R, f = camera(t)
        quad = project(corners_3d(), eye, R, f)
        bez = project(corners_3d(1.075), eye, R, f)
        truth[str(i)] = quad.tolist()

        frame = background(eye, R, f)

        # bezel
        cv2.fillConvexPoly(frame, bez.astype(np.int32), (0.055, 0.055, 0.062))

        # screen
        M = cv2.getPerspectiveTransform(src, quad)
        warped = cv2.warpPerspective(content, M, (W, H), flags=cv2.INTER_LANCZOS4)
        m = np.zeros((H, W), np.float32)
        cv2.fillConvexPoly(m, quad.astype(np.int32), 1.0)
        m = cv2.GaussianBlur(m, (3, 3), 0)[..., None]
        frame = frame * (1 - m) + warped * m

        # glare band raking across the glass
        gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
        band = np.exp(-((gx * 0.6 + gy * 0.8 - (380 + 520 * t) * 1.4) ** 2) / (2 * 230.0 ** 2))
        frame = frame + (band[..., None] * m * 0.17)

        # falloff so the panel isn't uniformly lit
        frame = frame * (1 - m * 0.10 * (gx / W)[..., None])

        # vignette, lens softness, grain
        d = np.sqrt((gx / W - 0.5) ** 2 + (gy / H - 0.5) ** 2)
        frame *= (1 - 0.38 * np.clip(d / 0.72, 0, 1) ** 2)[..., None]
        frame = cv2.GaussianBlur(frame, (0, 0), 0.7)
        frame += rng.normal(0, 0.011, frame.shape).astype(np.float32)

        cv2.imwrite(os.path.join(OUT, f'{i:05d}.png'),
                    (np.clip(frame, 0, 1) * 255).astype(np.uint8))

    json.dump({'fps': FPS, 'width': W, 'height': H, 'frames': truth},
              open(os.path.join(OUT, '..', 'test-plate-truth.json'), 'w'))
    print(f'{N} frames -> {OUT}')
    print('frame 0 corners:',
          ' '.join(f'{x:.0f},{y:.0f}' for x, y in truth['0']))


if __name__ == '__main__':
    main()
