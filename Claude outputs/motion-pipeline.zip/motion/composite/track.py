#!/usr/bin/env python3
"""
track.py — planar track of a device screen through a live-action plate.

Mark the four screen corners once, on one frame. This follows them
through the clip and writes a per-frame quad that comp.py warps the
prototype into.

    python3 track.py --plate plate.mp4 \
        --corners "812,344 1456,392 1448,790 806,742" \
        --ref 0 --out track.json

Corners are TL TR BR BL as you look at the screen, in pixels.

Method: Lucas-Kanade optical flow on features inside the screen and on
a ring of bezel around it, then a RANSAC homography per frame step.
Tracking the bezel as well as the screen matters — a screen showing a
flat bright image has very little to lock onto, and the bezel is rigid
with respect to it.
"""

import argparse
import json
import sys

import cv2
import numpy as np


def quad_mask(shape, quad, grow=0.0, ring=0.0):
    """Mask of the quad, optionally grown, optionally as a ring around it."""
    h, w = shape[:2]
    c = quad.mean(axis=0)

    def scaled(f):
        return (c + (quad - c) * f).astype(np.int32)

    m = np.zeros((h, w), np.uint8)
    if ring > 0:
        cv2.fillConvexPoly(m, scaled(1.0 + ring), 255)
        cv2.fillConvexPoly(m, scaled(1.0 + grow), 0)
    else:
        cv2.fillConvexPoly(m, scaled(1.0 + grow), 255)
    return m


def detect(gray, quad, n=600):
    """Features inside the screen plus a ring of bezel around it."""
    inside = quad_mask(gray.shape, quad, grow=-0.04)
    around = quad_mask(gray.shape, quad, grow=0.02, ring=0.22)
    mask = cv2.bitwise_or(inside, around)
    pts = cv2.goodFeaturesToTrack(
        gray, maxCorners=n, qualityLevel=0.01, minDistance=7,
        mask=mask, blockSize=7,
    )
    return pts if pts is not None else np.empty((0, 1, 2), np.float32)


LK = dict(
    winSize=(21, 21), maxLevel=4,
    criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 40, 0.01),
)


def step(prev_gray, gray, pts):
    """One frame of flow. Returns (mask, moved_points) where mask selects
    the input points that survived a forward-backward round trip, so the
    caller can subset its own parallel arrays by the same mask."""
    if len(pts) < 8:
        return None, None
    nxt, st, _ = cv2.calcOpticalFlowPyrLK(prev_gray, gray, pts, None, **LK)
    if nxt is None:
        return None, None
    back, st2, _ = cv2.calcOpticalFlowPyrLK(gray, prev_gray, nxt, None, **LK)
    if back is None:
        return None, None

    fb = np.linalg.norm(pts - back, axis=2).ravel()
    ok = (st.ravel() == 1) & (st2.ravel() == 1) & (fb < 1.0)
    if ok.sum() < 8:
        return None, None
    return ok, nxt[ok]


def smooth(series, win=9, order=2):
    """Light Savitzky-Golay on each corner coordinate to kill jitter
    without eating the real camera move."""
    from scipy.signal import savgol_filter
    a = np.asarray(series, np.float64)
    if len(a) < win:
        return a
    out = a.copy()
    for i in range(a.shape[1]):
        for j in range(a.shape[2]):
            out[:, i, j] = savgol_filter(a[:, i, j], win, order)
    return out


def run_direction(frames, start, quad, reverse=False):
    """Walk the clip from the reference frame, carrying the quad along.

    Every frame's quad is solved from the REFERENCE frame, not from the
    previous one. Flow still runs frame to frame — that's what it's good
    at — but each tracked point remembers where it sat in the reference
    frame, so the homography is always ref -> current and the error
    can't compound. Chaining per-frame homographies instead drifts
    steadily: on the synthetic plate it reached 23px by the last frame,
    which slides visibly.
    """
    order = range(start - 1, -1, -1) if reverse else range(start + 1, len(frames))
    prev_gray = frames[start]

    cur_pts = detect(prev_gray, quad)
    ref_pts = cur_pts.copy()          # same frame, so they start equal
    cur = quad.copy()
    out = {}
    lost = 0

    for i in order:
        gray = frames[i]
        mask, moved = step(prev_gray, gray, cur_pts)
        if mask is None:
            lost += 1
            if lost > 3:
                print(f'  ! track lost at frame {i}', file=sys.stderr)
                break
            out[i] = cur.copy()
            prev_gray = gray
            continue

        # the same mask subsets the reference-space copies, keeping the
        # two arrays index-aligned
        ref_keep = ref_pts[mask]
        H_cur, inl = cv2.findHomography(ref_keep, moved, cv2.RANSAC, 1.5, maxIters=5000)
        if H_cur is None or inl is None or inl.sum() < 10:
            lost += 1
            out[i] = cur.copy()
            prev_gray = gray
            continue

        lost = 0
        inl = inl.ravel().astype(bool)
        ref_pts, cur_pts = ref_keep[inl], moved[inl]
        cur = cv2.perspectiveTransform(
            quad.reshape(-1, 1, 2), H_cur).reshape(4, 2)
        out[i] = cur.copy()

        # top the point set back up as features leave frame, mapping the
        # new ones back into reference space through the current solve
        if len(cur_pts) < 150:
            fresh = detect(gray, cur)
            if len(fresh):
                back = cv2.perspectiveTransform(fresh, np.linalg.inv(H_cur))
                ref_pts = np.vstack([ref_pts, back]).astype(np.float32)
                cur_pts = np.vstack([cur_pts, fresh]).astype(np.float32)

        prev_gray = gray

    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--plate', required=True)
    ap.add_argument('--corners', default=None,
                    help='"x,y x,y x,y x,y" as TL TR BR BL')
    ap.add_argument('--ref', type=int, default=-1,
                    help='frame the corners were marked on; default is the '
                         'middle frame, which roughly halves tracking error')
    ap.add_argument('--dump-frame', type=int, default=None,
                    help='write this frame to PNG and exit, to read corners off')
    ap.add_argument('--out', required=True)
    ap.add_argument('--no-smooth', action='store_true')
    args = ap.parse_args()

    if args.dump_frame is not None:
        cap = cv2.VideoCapture(args.plate)
        cap.set(cv2.CAP_PROP_POS_FRAMES, args.dump_frame)
        ok, f = cap.read()
        cap.release()
        if not ok:
            sys.exit(f'could not read frame {args.dump_frame}')
        out = args.out if args.out.endswith('.png') else f'frame_{args.dump_frame}.png'
        cv2.imwrite(out, f)
        print(f'frame {args.dump_frame} -> {out}  ({f.shape[1]}x{f.shape[0]})')
        return

    if not args.corners:
        sys.exit('need --corners (or --dump-frame to read them off a frame)')
    quad = np.array([[float(v) for v in p.split(',')]
                     for p in args.corners.split()], np.float32)
    if quad.shape != (4, 2):
        sys.exit('need exactly 4 corners')

    cap = cv2.VideoCapture(args.plate)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frames, color_shape = [], None
    while True:
        ok, f = cap.read()
        if not ok:
            break
        color_shape = f.shape
        frames.append(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY))
    cap.release()

    if not frames:
        sys.exit('no frames read from plate')
    ref = args.ref if args.ref >= 0 else len(frames) // 2
    print(f'{len(frames)} frames @ {fps:.3f}fps, {color_shape[1]}x{color_shape[0]}')

    quads = {ref: quad.copy()}
    quads.update(run_direction(frames, ref, quad, reverse=False))
    quads.update(run_direction(frames, ref, quad, reverse=True))

    idx = sorted(quads)
    series = np.array([quads[i] for i in idx])
    if not args.no_smooth:
        series = smooth(series)

    json.dump({
        'plate': args.plate,
        'fps': fps,
        'width': int(color_shape[1]),
        'height': int(color_shape[0]),
        'frames': {str(i): series[k].tolist() for k, i in enumerate(idx)},
    }, open(args.out, 'w'))

    print(f'tracked {len(idx)}/{len(frames)} frames -> {args.out}')
    if len(idx) < len(frames):
        print(f'  {len(frames) - len(idx)} frames dropped; '
              f'usable range is {idx[0]}-{idx[-1]}')


if __name__ == '__main__':
    main()
