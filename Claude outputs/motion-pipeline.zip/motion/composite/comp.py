#!/usr/bin/env python3
"""
comp.py — warp a prototype render into a tracked screen and grade it in.

    python3 comp.py --plate plate.mp4 --track track.json \
        --content ../work/planning-mode-screen-light \
        --out ../out/pm-plate.mp4 --content-start 90

A straight paste reads as a sticker. What sells it is everything after
the warp: the screen's own glare kept on top, light spilling onto the
bezel, the plate's grain laid back over, and the blur of the real lens
matched. Each of those is a flag here so they can be dialled per plate.
"""

import argparse
import json
import os
import subprocess
import sys

import cv2
import numpy as np


def load_content(path):
    files = sorted(f for f in os.listdir(path)
                   if f.lower().endswith(('.jpg', '.jpeg', '.png')))
    if not files:
        sys.exit(f'no frames in {path}')
    return [os.path.join(path, f) for f in files]


def soft_mask(shape, quad, feather):
    """Quad mask with a feathered edge, so the composite doesn't end on
    a hard pixel line where the real screen has a soft bezel shadow."""
    h, w = shape[:2]
    m = np.zeros((h, w), np.float32)
    cv2.fillConvexPoly(m, quad.astype(np.int32), 1.0)
    if feather > 0:
        k = int(feather) | 1
        m = cv2.GaussianBlur(m, (k, k), 0)
    return m


def screen_blend(base, top, amount):
    """Photographic screen blend — used to put the plate's own glare
    back over the new content."""
    return base + (1.0 - base) * top * amount


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--plate', required=True)
    ap.add_argument('--track', required=True)
    ap.add_argument('--content', required=True, help='dir of prototype frames')
    ap.add_argument('--out', required=True)
    ap.add_argument('--content-start', type=int, default=0,
                    help='first prototype frame to use')
    ap.add_argument('--content-hold', action='store_true',
                    help='hold the last prototype frame instead of looping')
    ap.add_argument('--start', type=int, default=None, help='first plate frame')
    ap.add_argument('--end', type=int, default=None, help='last plate frame')

    ap.add_argument('--glare', type=float, default=0.45,
                    help='how much of the real screen glare to keep (0-1)')
    ap.add_argument('--glare-floor', type=float, default=0.25,
                    help='how far above the screen median counts as glare, '
                         'as a fraction of the headroom left (0-1)')
    ap.add_argument('--glare-blur', type=float, default=0.02,
                    help='glare lowpass, as a fraction of the long edge')
    ap.add_argument('--spill', type=float, default=0.35,
                    help='light thrown from the screen onto the bezel')
    ap.add_argument('--grain', type=float, default=1.0,
                    help='how much of the plate grain to lay back over')
    ap.add_argument('--blur', type=float, default=0.6,
                    help='lens softness on the composited content, px')
    ap.add_argument('--exposure', type=float, default=1.0)
    ap.add_argument('--feather', type=int, default=5)
    ap.add_argument('--debug-quad', action='store_true',
                    help='draw the tracked quad, for checking the track')
    args = ap.parse_args()

    tr = json.load(open(args.track))
    quads = {int(k): np.array(v, np.float32) for k, v in tr['frames'].items()}
    fps = tr['fps']

    content = load_content(args.content)
    cap = cv2.VideoCapture(args.plate)

    lo = args.start if args.start is not None else min(quads)
    hi = args.end if args.end is not None else max(quads)

    work = os.path.splitext(args.out)[0] + '_frames'
    os.makedirs(work, exist_ok=True)
    for f in os.listdir(work):
        os.remove(os.path.join(work, f))

    n_out = 0
    i = -1
    while True:
        ok, plate = cap.read()
        if not ok:
            break
        i += 1
        if i < lo or i > hi or i not in quads:
            continue

        quad = quads[i]
        H, W = plate.shape[:2]
        p = plate.astype(np.float32) / 255.0

        # ---- pick the prototype frame for this plate frame ----
        ci = args.content_start + (i - lo)
        if ci >= len(content):
            ci = len(content) - 1 if args.content_hold else \
                args.content_start + ((i - lo) % max(1, len(content) - args.content_start))
        src = cv2.imread(content[ci]).astype(np.float32) / 255.0
        sh, sw = src.shape[:2]

        # ---- warp it onto the tracked quad ----
        M = cv2.getPerspectiveTransform(
            np.array([[0, 0], [sw, 0], [sw, sh], [0, sh]], np.float32), quad)
        warped = cv2.warpPerspective(
            src, M, (W, H), flags=cv2.INTER_LANCZOS4,
            borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0))

        if args.blur > 0:
            k = int(args.blur * 4) | 1
            warped = cv2.GaussianBlur(warped, (k, k), args.blur)

        warped = np.clip(warped * args.exposure, 0, 1)

        mask = soft_mask(plate.shape, quad, args.feather)[..., None]

        # ---- keep the real screen's glare on top of the new content ----
        # Glare is low-frequency: a broad bright band raked across the
        # glass. The content underneath is high-frequency. So blur hard
        # first, then judge brightness RELATIVE to the screen's own mean
        # — otherwise a bright screen reads as all-glare and washes the
        # composite out, and sharp text survives the threshold and
        # ghosts through the new UI.
        if args.glare > 0:
            lum = cv2.cvtColor(plate, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
            low = cv2.GaussianBlur(lum, (0, 0), max(W, H) * args.glare_blur)
            inside = mask[..., 0] > 0.5
            base = float(np.median(low[inside])) if inside.any() else 0.5
            span = max(1e-3, 1.0 - base)
            glare = np.clip((low - base - args.glare_floor * span) / span, 0, 1)
            warped = screen_blend(warped, glare[..., None], args.glare)

        out = p * (1 - mask) + warped * mask

        # ---- light spilling from the screen onto the bezel ----
        if args.spill > 0:
            halo = cv2.GaussianBlur(
                (warped * mask), (0, 0), max(W, H) * 0.012)
            ring = np.clip(
                cv2.GaussianBlur(mask[..., 0], (0, 0), max(W, H) * 0.012)[..., None]
                - mask, 0, 1)
            out = screen_blend(out, halo * ring, args.spill)

        # ---- lay the plate's own grain back over the new area ----
        if args.grain > 0:
            den = cv2.bilateralFilter(plate, 7, 40, 7).astype(np.float32) / 255.0
            noise = p - den
            out = out + noise * mask * args.grain

        out = np.clip(out, 0, 1)

        if args.debug_quad:
            cv2.polylines(out, [quad.astype(np.int32)], True, (0, 0, 1), 2)
            for c in quad.astype(int):
                cv2.circle(out, tuple(c), 5, (0, 1, 1), -1)

        cv2.imwrite(os.path.join(work, f'{n_out:05d}.png'),
                    (out * 255).astype(np.uint8))
        n_out += 1
        if n_out % 30 == 0:
            print(f'  {n_out} frames', flush=True)

    cap.release()
    if n_out == 0:
        sys.exit('nothing composited — check --start/--end against the track range')

    subprocess.run([
        'ffmpeg', '-nostdin', '-v', 'error', '-y',
        '-framerate', str(fps), '-i', os.path.join(work, '%05d.png'),
        '-c:v', 'libx264', '-profile:v', 'high', '-crf', '18',
        '-preset', 'slow', '-pix_fmt', 'yuv420p', '-movflags', '+faststart',
        '-an', args.out,
    ], check=True)
    print(f'{n_out} frames -> {args.out}')


if __name__ == '__main__':
    main()
