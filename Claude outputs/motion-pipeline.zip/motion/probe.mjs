/* Grab a handful of named moments from a scene, tiled into one
   sheet, so a look can be judged without rendering the whole film. */

import { chromium } from 'playwright-core';
import { serve, CHROME_ARGS } from './kit/serve.mjs';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __dir = path.dirname(fileURLToPath(import.meta.url));
const arg = (n, d) => { const i = process.argv.indexOf('--' + n); return i > -1 ? process.argv[i + 1] : d; };

const scene = arg('scene');
const W = parseInt(arg('w', '1920'), 10);
const H = parseInt(arg('h', '1080'), 10);
const theme = arg('theme', 'light');
const mode = arg('mode', 'hero');
const at = (arg('at', '') || '').split(',').filter(Boolean).map(Number);
const outDir = path.join(__dir, 'work', 'probe');
fs.mkdirSync(outDir, { recursive: true });

const { server, port } = await serve(__dir);
const base = `http://127.0.0.1:${port}`;

const browser = await chromium.launch({
  executablePath: '/usr/bin/google-chrome',
  args: CHROME_ARGS,
});
const page = await browser.newPage({ viewport: { width: W, height: H } });
page.on('pageerror', (e) => console.error('  [page error]', e.message));
page.on('console', (m) => { if (m.type() === 'error') console.error('  [page]', m.text()); });

await page.goto(`${base}/scenes/${scene}.html` + `?w=${W}&h=${H}&theme=${theme}&mode=${mode}`, { waitUntil: 'load' });
await page.waitForFunction('window.__ready === true', { timeout: 30000 });
await page.evaluate(() => document.fonts.ready);

const duration = await page.evaluate('window.__duration');
console.log('duration', (duration / 1000).toFixed(2) + 's');

const times = at.length ? at : Array.from({ length: 9 }, (_, i) => Math.round((duration * i) / 8));
let n = 0;
for (const t of times) {
  await page.evaluate((ms) => window.__seek(ms), t);
  await page.screenshot({ path: path.join(outDir, `${scene}-${mode}-${String(n).padStart(2, '0')}-${t}.png`) });
  n++;
}
await browser.close();
server.close();
console.log('probed', times.join(', '));
