# motion

Films of the work, built from the prototypes rather than from screen
captures. Two halves:

- **`scenes/`** — the prototypes themselves, rebuilt as HTML and driven
  by a deterministic timeline, so they can be rendered at any size and
  re-rendered identically.
- **`composite/`** — screen replacement: track a device screen in a
  live-action plate, warp a prototype into it, grade it in.

## Why the prototypes are rebuilt

The original screen recordings top out at 1024px tall, and the Assistant
panel in them turns to mush at ad resolution. The Skills recording was
also a single static frame for 56 of its 66 seconds. Rebuilding the UI
means it renders crisp at 2560×1600, the performance can be retimed
without a re-record, and the same scene serves every output size.

## Determinism

Nothing in `kit/kit.js` reads the wall clock. Every animated value is a
function of `t` in milliseconds, and the renderer seeks to an exact `t`
per frame. Re-running a build produces the same pixels. CSS animations
and `requestAnimationFrame` would drift against a frame-by-frame
screenshot loop, which is why they aren't used.

## Rendering

```sh
npm install
./build.sh planning-mode hero light     # 1920x1080 case-study film
./build.sh planning-mode card light     # 1536x1024 silent loop for the grid
node render.mjs --scene skills --mode screen \
  --w 1280 --h 800 --scale 2 --fps 30   # UI only, for compositing
```

Modes:

| mode | what it is | chrome |
|---|---|---|
| `hero` | 16:9 film with captions and an end card | device frame on a backdrop |
| `card` | 3:2 silent loop for the work grid | device frame, no copy |
| `screen` | the UI alone at the display's aspect | none — this gets warped into a plate |

`--scale 2` renders at 2× for Retina-correct UI proportions: the layout
is laid out at 1280×800 and output at 2560×1600.

Frames are captured as JPEG, not PNG. Chrome's PNG encoder costs about
820ms a frame against 77ms for JPEG at q96, and the frames only exist to
be fed to x264.

## Screen replacement

```sh
cd composite

# 1. find a frame to mark corners on
python3 track.py --plate plate.mp4 --dump-frame 90 --out frame.png

# 2. track. corners are TL TR BR BL in pixels
python3 track.py --plate plate.mp4 \
  --corners "517,272 1439,271 1399,824 592,756" --out track.json

# 3. composite
python3 comp.py --plate plate.mp4 --track track.json \
  --content ../work/planning-mode-screen-light \
  --out ../out/pm-plate.mp4 --content-start 60 --content-hold
```

**Mark the corners on a middle frame.** `--ref` defaults to the middle
of the clip for this reason. On the test plate, tracking from frame 0
gives 29px mean error; from the middle frame it gives 1.5px. The tracker
only has to reach half as far in each direction, and the reference view
is closer to average across the move.

Each frame's quad is solved from the reference frame, never from the
previous frame. Chaining per-frame homographies accumulates drift —
23px by the end of a 6-second move, which slides visibly.

Dial per plate: `--glare`, `--glare-floor`, `--spill`, `--grain`,
`--blur`, `--exposure`. Run with `--debug-quad` to check the track
before spending time on the grade.

### Checking the tracker

`composite/make_test_plate.py` renders a synthetic plate with known
corner positions, so tracking accuracy can be measured rather than
eyeballed. The background is projected through the same camera as the
screen — an earlier version painted it once and reused it, which made
every background feature report zero motion and dragged the solve
toward identity.

## Buying plates

See `PLATES.md`. The first four items there are hard requirements: a
clip that fails them can't be tracked, however good it looks.

## Regenerating build inputs

The Planning Mode payoff uses real Studio footage cut out of the
original recording:

```sh
./extract-media.sh
```
