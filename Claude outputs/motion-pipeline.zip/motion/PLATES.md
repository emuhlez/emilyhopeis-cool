# Buying plates for screen replacement

A "plate" is the live-action clip the prototype gets composited into. The
clip you buy decides whether the track is solvable, so this list is not
a style preference — the first four items are hard requirements.

## Hard requirements

1. **The screen is visible and unoccluded for the whole clip.**
   No hand crossing the display, no hair over a corner, no cut-off edges.
   All four corners of the screen inside frame the whole time. If a corner
   leaves frame or a hand passes over it, that section can't be tracked
   and has to be thrown away.

2. **The screen is ON and showing something, ideally bright and flat.**
   A dark or off screen gives nothing to track and no light to match.
   A generic desktop, a document, a code editor — anything. Avoid clips
   where the screen is blown out to pure white: the replacement will
   look pasted on because there's no falloff to match.

3. **Modest, continuous camera motion.**
   A slow push, a gentle handheld drift, a slight orbit — all good, and
   motion actually helps it feel real. What kills it: whip pans, cuts
   inside the clip, heavy rolling-shutter wobble, and anything where the
   screen is motion-blurred beyond reading.

4. **4K, 24 or 30fps, and at least 8 seconds.**
   4K matters because the screen is a small part of the frame and the
   prototype has to stay legible after it's warped into that area. Buy
   8–15s clips; I'll cut them down.

## What to look for

- **MacBook at a desk.** Three-quarter angle from the side, or
  over-the-shoulder. The screen should fill roughly a quarter to a half
  of the frame. Warm practical light — a window, a desk lamp.
- **External display.** Someone at a monitor, shot from behind or from
  the side. Good for the Emily's Desktop piece since it's already a
  Studio Display.
- **A macro beat.** A tight shot of fingers on a trackpad or keyboard
  with part of the screen in frame and the rest falling into bokeh.
  This is the shot that sells craft, and it's the one in his film.
- **One face.** A cutaway of someone looking at the screen, reacting.
  No screen needed in this one, so there's no compositing to do — it
  just cuts in. One of these makes the whole thing feel like an ad
  rather than a UI demo.

## Avoid

- Anyone looking directly at camera or presenting to it.
- Visible brand logos on the device or in the room.
- Obvious stock-photo energy: forced smiles, sterile white offices,
  people pointing at a screen together.
- Clips where the screen already shows a recognisable product UI —
  harder to cover cleanly, and it dates the shot.
- Heavy colour grading baked in. Neutral grades composite better.

## Aspect / framing of the screen itself

Tell me the device in each clip so I render the prototype at the right
shape before warping:

- MacBook → 16:10
- Studio Display / most monitors → 16:9

## What I need from you

Drop the clips in a folder and tell me where. For each one, a word on
what it is ("macbook three-quarter", "trackpad macro", "face cutaway").
I'll pull the usable takes, track the screens, composite the prototypes
in, and grade them to match.

## Shot order I'd cut to

A 20-second piece wants about five plates:

1. Macro — fingers, screen edge, bokeh. Establishes texture.
2. Three-quarter MacBook — the prompt goes in. Caption lands here.
3. Face cutaway — a beat of reaction. No compositing.
4. Three-quarter or over-shoulder — the plan appears, gets edited.
5. Push in on the screen — the build pays off. Hold, then end card.
