#!/usr/bin/env bash
# Cut the real Studio render out of the original recording. The fountain
# is the one genuinely good stretch in that 44s capture; the screen
# region is cropped out of the baked-in laptop mockup so it can sit
# inside our own frame instead.
set -euo pipefail
cd "$(dirname "$0")"

SRC="../images/work/planning-mode-card.mp4"
[ -f "$SRC" ] || SRC="$HOME/mnt/emilyhopeiscool-web/images/work/planning-mode-card.mp4"
[ -f "$SRC" ] || { echo "can't find planning-mode-card.mp4"; exit 1; }

OUT="scenes/media/pm-payoff"
mkdir -p "$OUT"
# crop = the laptop's screen rect in that recording, measured off the bezel
ffmpeg -nostdin -v error -ss 33.5 -t 8 -i "$SRC" \
  -vf "crop=1396:878:70:86,fps=30" -q:v 3 -y "$OUT/%04d.jpg"
echo "$(ls "$OUT" | wc -l) frames -> $OUT"
