#!/usr/bin/env bash
# Render a scene to PNG frames, then encode for the web.
#
#   ./build.sh <scene> <mode> <theme>
#
# mode  hero -> 1920x1080 case-study film
#       card -> 1536x1024 silent loop for the work grid
set -euo pipefail

cd "$(dirname "$0")"

SCENE="${1:?scene}"
MODE="${2:-hero}"
THEME="${3:-light}"
FPS=30

if [ "$MODE" = "hero" ]; then W=1920; H=1080; CRF=20; else W=1536; H=1024; CRF=22; fi

FRAMES="work/${SCENE}-${MODE}-${THEME}"
SUFFIX=""
[ "$THEME" = "dark" ] && SUFFIX="-dark"
OUT="out/${SCENE}-${MODE}${SUFFIX}.mp4"

mkdir -p out

node render.mjs --scene "$SCENE" --mode "$MODE" --theme "$THEME" --w "$W" --h "$H" --fps "$FPS"

ffmpeg -nostdin -v error -stats \
  -framerate "$FPS" -i "$FRAMES/%05d.jpg" \
  -c:v libx264 -profile:v high -crf "$CRF" -preset slow \
  -pix_fmt yuv420p -movflags +faststart -an \
  -y "$OUT"

# poster frame: the moment the product is fully on screen, not frame 0
POSTER="out/${SCENE}-${MODE}${SUFFIX}.jpg"
TOTAL=$(ls "$FRAMES" | wc -l)
PICK=$(( TOTAL * 55 / 100 ))
cp "$FRAMES/$(printf '%05d' $PICK).jpg" "$POSTER"

printf '  %s  %s  %s\n' "$OUT" "$(du -h "$OUT" | cut -f1)" "$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$OUT")s"
