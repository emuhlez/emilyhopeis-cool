/* ============================================================
   motion kit — deterministic timeline engine
   ------------------------------------------------------------
   Every animated value is a pure function of t (milliseconds).
   Nothing reads the wall clock, so seeking to frame N always
   produces exactly the same pixels. That is what makes the
   renders reproducible: re-running the build cannot drift.
   ============================================================ */

/* ---------- easing ---------- */

function bezier(x1, y1, x2, y2) {
  const cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx;
  const cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by;
  const sampleX = (t) => ((ax * t + bx) * t + cx) * t;
  const sampleY = (t) => ((ay * t + by) * t + cy) * t;
  const slopeX = (t) => (3 * ax * t + 2 * bx) * t + cx;
  return function (x) {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    let t = x;
    for (let i = 0; i < 8; i++) {
      const d = sampleX(t) - x;
      if (Math.abs(d) < 1e-6) return sampleY(t);
      const s = slopeX(t);
      if (Math.abs(s) < 1e-6) break;
      t -= d / s;
    }
    let lo = 0, hi = 1;
    t = x;
    while (lo < hi) {
      const v = sampleX(t);
      if (Math.abs(v - x) < 1e-6) break;
      if (v < x) lo = t; else hi = t;
      t = (hi - lo) / 2 + lo;
      if (hi - lo < 1e-7) break;
    }
    return sampleY(t);
  };
}

export const Ease = {
  linear: (t) => t,
  smooth: bezier(0.4, 0, 0.2, 1),
  snappy: bezier(0.2, 0, 0, 1),
  gentle: bezier(0.33, 0, 0.17, 1),
  flow: bezier(0.65, 0, 0.35, 1),
  out: bezier(0, 0, 0.2, 1),
  in: bezier(0.5, 0, 1, 1),
  overshoot: bezier(0.34, 1.4, 0.64, 1),
};

/* ---------- timing scale ----------
   One ladder of durations for the whole system, so a panel
   reveal in one film has the same weight as in another. */
export const Dur = {
  tap: 120,
  quick: 200,
  base: 320,
  reveal: 480,
  settle: 720,
  slow: 950,
  drift: 1400,
  hold: 2000,
};

export const STAGGER = 60;

/* ---------- value model ----------
   Each element accumulates a plain object of properties per
   seek, then gets one style write. Overlapping tracks compose
   instead of fighting over style.transform. */

const BASE = () => ({
  x: 0, y: 0, z: 0, scale: 1, rotate: 0,
  opacity: 1, blur: 0, bright: 1,
  clip: null, width: null, height: null, origin: null,
});

/* An element may carry a transform from the stylesheet (a tick mark
   rotated 45deg, say). Capture it once and compose onto it, so
   animating `scale` never silently drops the authored rotation. */
const BASE_TF = new WeakMap();
function baseTransform(el) {
  if (!BASE_TF.has(el)) {
    const t = getComputedStyle(el).transform;
    BASE_TF.set(el, !t || t === 'none' ? '' : t);
  }
  return BASE_TF.get(el);
}

function applyProps(el, p) {
  const tf = [];
  const base = baseTransform(el);
  if (base) tf.push(base);
  if (p.x || p.y || p.z) tf.push(`translate3d(${p.x}px, ${p.y}px, ${p.z}px)`);
  if (p.scale !== 1) tf.push(`scale(${p.scale})`);
  if (p.rotate) tf.push(`rotate(${p.rotate}deg)`);
  el.style.transform = tf.length ? tf.join(' ') : 'none';
  /* Always write a number. Clearing to '' would hand control back to
     the stylesheet, which is how a faded-in layer stays invisible. */
  el.style.opacity = String(p.opacity);
  const fl = [];
  if (p.blur) fl.push(`blur(${p.blur}px)`);
  if (p.bright !== 1) fl.push(`brightness(${p.bright})`);
  el.style.filter = fl.length ? fl.join(' ') : '';
  if (p.origin) el.style.transformOrigin = p.origin;
  if (p.clip !== null) el.style.clipPath = `inset(0 ${100 - p.clip * 100}% 0 0)`;
  if (p.width !== null) el.style.width = p.width + 'px';
  if (p.height !== null) el.style.height = p.height + 'px';
}

/* ---------- timeline ---------- */

export class Timeline {
  constructor(root = document) {
    this.root = root;
    this.tracks = [];
    this.duration = 0;
    this._cache = new Map();
  }

  _els(sel) {
    if (typeof sel !== 'string') return [sel];
    if (!this._cache.has(sel)) {
      this._cache.set(sel, Array.from(this.root.querySelectorAll(sel)));
    }
    return this._cache.get(sel);
  }

  _push(track) {
    this.tracks.push(track);
    this.duration = Math.max(this.duration, track.at + (track.dur || 0));
    return this;
  }

  /* animate numeric props: anim(sel, {opacity:[0,1], y:[16,0]}, {at, dur, ease, stagger}) */
  anim(sel, props, { at = 0, dur = Dur.reveal, ease = 'snappy', stagger = 0, origin } = {}) {
    this._els(sel).forEach((el, i) => {
      this._push({
        kind: 'anim', el, props, origin,
        at: at + i * stagger, dur, ease,
      });
    });
    return this;
  }

  /* hold a static prop set from `at` onward (initial states) */
  set(sel, props, { at = 0 } = {}) {
    this._els(sel).forEach((el) => {
      this._push({ kind: 'set', el, props, at, dur: 0 });
    });
    return this;
  }

  /* add/remove a class at a moment */
  cls(sel, name, { at = 0, on = true } = {}) {
    this._els(sel).forEach((el) => {
      this._push({ kind: 'cls', el, name, on, at, dur: 0 });
    });
    return this;
  }

  /* typewriter — reveals `text` character by character */
  type(sel, text, { at = 0, dur = Dur.drift, ease = 'linear' } = {}) {
    this._els(sel).forEach((el) => {
      this._push({ kind: 'type', el, text, at, dur, ease });
    });
    return this;
  }

  /* swap an <img> through a pre-extracted frame sequence */
  footage(sel, { at = 0, dur, dir, from = 0, count, fps = 30, pad = 4, ext = 'jpg' }) {
    this._els(sel).forEach((el) => {
      this._push({ kind: 'footage', el, at, dur, dir, from, count, fps, pad, ext });
    });
    return this;
  }

  /* text content set at a moment (no typing) */
  text(sel, value, { at = 0 } = {}) {
    this._els(sel).forEach((el) => {
      this._push({ kind: 'text', el, value, at, dur: 0 });
    });
    return this;
  }

  seek(t) {
    this.pending = [];
    const state = new Map();
    const getState = (el) => {
      if (!state.has(el)) state.set(el, BASE());
      return state.get(el);
    };
    const touched = new Set();
    const classes = new Map();
    const texts = new Map();

    for (const tr of this.tracks) {
      const el = tr.el;
      if (!el) continue;

      if (tr.kind === 'cls') {
        if (t >= tr.at) {
          if (!classes.has(el)) classes.set(el, new Map());
          classes.get(el).set(tr.name, tr.on);
        }
        continue;
      }

      if (tr.kind === 'text') {
        if (t >= tr.at) texts.set(el, tr.value);
        continue;
      }

      if (tr.kind === 'type') {
        /* Contributes nothing before it starts, so an element that
           already has copy keeps showing it until the retype begins.
           Clear explicitly with .text() when you want it blank. */
        if (t < tr.at) continue;
        const p = tr.dur > 0 ? Math.min(1, (t - tr.at) / tr.dur) : 1;
        const e = Ease[tr.ease] ? Ease[tr.ease](p) : p;
        const n = Math.round(e * tr.text.length);
        texts.set(el, tr.text.slice(0, n));
        continue;
      }

      if (tr.kind === 'footage') {
        if (t < tr.at) continue;
        const local = Math.min(t - tr.at, (tr.dur ?? Infinity));
        let idx = tr.from + Math.floor((local / 1000) * tr.fps);
        if (tr.count) idx = Math.min(idx, tr.from + tr.count - 1);
        const name = String(idx).padStart(tr.pad, '0');
        const src = `${tr.dir}/${name}.${tr.ext}`;
        if (el.getAttribute('src') !== src) {
          el.setAttribute('src', src);
          // the renderer awaits these: a screenshot taken before the
          // frame decodes would silently capture the previous one
          this.pending.push(el.decode().catch(() => {}));
        }
        continue;
      }

      const s = getState(el);
      touched.add(el);
      if (tr.origin) s.origin = tr.origin;

      if (tr.kind === 'set') {
        if (t >= tr.at) for (const k in tr.props) s[k] = tr.props[k];
        continue;
      }

      // kind === 'anim' — a track contributes nothing before it starts,
      // so chained moves on one property hand off cleanly instead of
      // the last-declared track yanking the value back at t=0.
      // Declare initial states with .set().
      if (t < tr.at) continue;
      const p = tr.dur > 0 ? Math.min(1, (t - tr.at) / tr.dur) : 1;
      const e = Ease[tr.ease] ? Ease[tr.ease](p) : Ease.linear(p);
      for (const k in tr.props) {
        const [a, b] = tr.props[k];
        s[k] = a + (b - a) * e;
      }
    }

    for (const el of touched) applyProps(el, state.get(el));
    for (const [el, map] of classes) {
      for (const [name, on] of map) el.classList.toggle(name, on);
    }
    for (const [el, v] of texts) {
      if (el.textContent !== v) el.textContent = v;
    }
  }
}

/* ---------- camera ----------
   A push-in is the single most "ad" gesture there is: a slow,
   continuous scale on the product shot under a cut-driven
   caption track. Everything else is held still so the move
   reads as intent rather than drift. */
export function pushIn(tl, sel, { at, dur = 4000, from = 1, to = 1.06, ease = 'flow', ox = 50, oy = 50 }) {
  return tl.anim(sel, { scale: [from, to] }, { at, dur, ease, origin: `${ox}% ${oy}%` });
}

/* A caption beat: eyebrow rule wipes, line rises, both leave together. */
export function captionBeat(tl, root, { at, hold = 2200 }) {
  const rule = `${root} .cap-rule`;
  const line = `${root} .cap-line`;
  tl.set(root, { opacity: 0 });
  tl.set(rule, { clip: 0 });
  tl.set(line, { opacity: 0, y: 18 });
  tl.anim(root, { opacity: [0, 1] }, { at, dur: Dur.quick, ease: 'out' });
  tl.anim(rule, { clip: [0, 1] }, { at, dur: Dur.settle, ease: 'snappy' });
  tl.anim(line, { y: [18, 0], opacity: [0, 1] }, { at: at + 80, dur: Dur.reveal, ease: 'snappy' });
  tl.anim(root, { opacity: [1, 0], y: [0, -10] }, { at: at + hold, dur: Dur.base, ease: 'in' });
  return at + hold + Dur.base;
}

/* Expose the engine to the renderer. */
export function mount(build) {
  const tl = new Timeline();
  build(tl);
  window.__duration = tl.duration;
  window.__seek = async (t) => {
    tl.seek(t);
    if (tl.pending && tl.pending.length) await Promise.all(tl.pending);
  };
  tl.seek(0);
  window.__ready = true;
  return tl;
}
