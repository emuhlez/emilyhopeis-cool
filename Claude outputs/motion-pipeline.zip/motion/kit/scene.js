/* Scene bootstrap: reads the render parameters off the URL so one
   scene file serves every aspect ratio and theme the build asks for. */

export function setup() {
  const q = new URLSearchParams(location.search);
  const W = parseInt(q.get('w') || '1920', 10);
  const H = parseInt(q.get('h') || '1080', 10);
  const theme = q.get('theme') || 'light';
  const mode = q.get('mode') || 'hero';

  const r = document.documentElement;
  r.style.setProperty('--W', W + 'px');
  r.style.setProperty('--H', H + 'px');
  r.setAttribute('data-theme', theme);
  r.setAttribute('data-mode', mode);

  return {
    W, H, theme, mode,
    hero: mode === 'hero',
    card: mode === 'card',
    screen: mode === 'screen',
  };
}

/* Place an element by its centre, in stage pixels. */
export function place(el, { w, h, cx, cy }) {
  el.style.position = 'absolute';
  el.style.width = w + 'px';
  el.style.height = h + 'px';
  el.style.left = Math.round(cx - w / 2) + 'px';
  el.style.top = Math.round(cy - h / 2) + 'px';
}

export const CURSOR_SVG = `
<svg viewBox="0 0 19 26" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M1.5 1.2 L1.5 20.4 L6.3 16.1 L9.5 23.8 L12.9 22.4 L9.7 14.9 L16.2 14.4 Z"
        fill="#fff" stroke="#1b1b1d" stroke-width="1.4" stroke-linejoin="round"/>
</svg>`;
