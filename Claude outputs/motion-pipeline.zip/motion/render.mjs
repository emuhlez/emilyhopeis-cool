/* ============================================================
   render.mjs — deterministic frame capture
   ------------------------------------------------------------
   Loads a scene, seeks it to an exact millisecond per frame and
   screenshots. No wall clock, no requestAnimationFrame, so the
   same scene always renders the same pixels.

   usage:
     node render.mjs --scene planning-mode --w 1920 --h 1080 \
                     --theme light --mode hero --fps 30
   ============================================================ */

import { chromium } from 'playwright-core';
import { serve, CHROME_ARGS } from './kit/serve.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dir = path.dirname(fileURLToPath(import.meta.url));

function arg(name, fallback) {
  const i = process.argv.indexOf('--' + name);
  return i > -1 ? process.argv[i + 1] : fallback;
}

const scene = arg('scene');
const W = parseInt(arg('w', '1920'), 10);
const H = parseInt(arg('h', '1080'), 10);
const theme = arg('theme', 'light');
const mode = arg('mode', 'hero');
const fps = parseInt(arg('fps', '30'), 10);
const scale = parseFloat(arg('scale', '1'));
const outDir = arg('out', path.join(__dir, 'work', `${scene}-${mode}-${theme}`));

if (!scene) { console.error('need --scene'); process.exit(1); }

fs.rmSync(outDir, { recursive: true, force: true });
fs.mkdirSync(outDir, { recursive: true });

const { server, port } = await serve(__dir);
const base = `http://127.0.0.1:${port}`;

const url =
  `${base}/scenes/${scene}.html` +
  `?w=${W}&h=${H}&theme=${theme}&mode=${mode}`;

const browser = await chromium.launch({
  executablePath: '/usr/bin/google-chrome',
  args: CHROME_ARGS,
});

const page = await browser.newPage({
  viewport: { width: W, height: H },
  deviceScaleFactor: scale,
});

page.on('console', (m) => { if (m.type() === 'error') console.error('  [page]', m.text()); });
page.on('pageerror', (e) => console.error('  [page error]', e.message));

await page.goto(url, { waitUntil: 'load' });
await page.waitForFunction('window.__ready === true', { timeout: 30000 });
await page.evaluate(() => document.fonts.ready);

const duration = await page.evaluate('window.__duration');
const total = Math.ceil((duration / 1000) * fps);

console.log(`${scene} · ${mode} · ${theme} — ${(duration / 1000).toFixed(2)}s · ${total} frames @ ${W}x${H}`);

const t0 = Date.now();
for (let f = 0; f < total; f++) {
  const t = (f / fps) * 1000;
  await page.evaluate((ms) => window.__seek(ms), t);
  /* JPEG, not PNG: Chrome's PNG encoder costs ~820ms a frame versus
     ~77ms here, and the frames only exist to be fed to x264. */
  await page.screenshot({
    path: path.join(outDir, String(f).padStart(5, '0') + '.jpg'),
    type: 'jpeg',
    quality: 96,
    animations: 'disabled',
  });
  if (f % 60 === 0 && f) {
    const pace = (Date.now() - t0) / f;
    process.stdout.write(`  ${f}/${total}  ~${Math.round((total - f) * pace / 1000)}s left\n`);
  }
}

await browser.close();
server.close();
console.log(`  done in ${Math.round((Date.now() - t0) / 1000)}s -> ${outDir}`);
